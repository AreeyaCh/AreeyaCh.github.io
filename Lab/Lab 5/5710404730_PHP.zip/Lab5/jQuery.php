<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Personal Information</title>
	<script  src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<style type="text/css">
		html {
	margin: 0;
	padding: 0;
	}

	.MainForm {
	background-color: #fffafa;
	border-style: dashed;
	border-color: #897264;
	margin-top: 50px;
	margin-left: 100px;
	margin-right: 100px;
	filter:alpha(opacity=40); 
	opacity:0.8;
	clear: right; 
	}

	body { 
	
	background-image: url("https://images5.alphacoders.com/302/302475.jpg");
	background-repeat: no-repeat;
	background-attachment: fixed;
	font: 75% georgia, sans-serif;
	color: #897264; 
	text-align: center;
	padding: 0;
	}

	h1{
	background-image: url("head1.png");
	margin-top: 10px;
	margin-left: 550px;
	margin-right: 460px;
	width: auto;
	height: 325px;
	text-indent: 100%;
	white-space: nowrap;
	overflow: hidden;
	}
	</style>
	<script type="text/javascript">
	
	$(document).ready(function(){
    $("#Clear").click(function(){
        document.getElementById('Form').reset();
    });
    $("#submit").click(function(){
    	var Radioval = $("input[name =gender]:checked").val();
  		var bday = $("input[type=date]").val();
  		var year = getAge(bday);
        if(year <= 13){
        	// window.open("childHTML.php");
          // localStorage.setItem('province',document.getElementById('province').value);
        	setAction("childHTML.php");
        }
        else if(Radioval == "male"){
        	// window.open("maleHTMl.php");
        	// localStorage.setItem('province',document.getElementById('province').value);
        	setAction("maleHTML.php");
        }
        else if(Radioval == "female"){
        	// window.open("femaleHTMl.php");
        	// localStorage.setItem('province',document.getElementById('province').value);
        	setAction("femaleHTML.php"); 
        }

    	});
	});

    function setAction(action_name){
        document.registerform.action = action_name;
    }
		
		function getAge(dateString) {
    var today = new Date();
    var birthDate = new Date(dateString);
    var age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    return age;
}

	</script>
</head>

<body>

	<h1>Form</h1>
	<form id = "Form" name = "registerform" action = "setAction(action_name)" method = "get">
	<div class = "MainForm" id = "main">
	<br>
	<br>
	Firstname : <input type="text" name="firstname" id="firstname" placeholder="firstname">
	<br>
	Lastname : <input type="text" name="lastname" id="lastname" placeholder="lastname">
	<br>
	Birthday : <input type="date" id="date">
	<br>
	<br>
	Gender :
	<input type="radio" name="gender" value="male">Male
	<input type="radio" name="gender" value="female">Female
	<br>
	Provice : 
	<select name="province" id = "province" >
      <option value="" selected>--------- เลือกจังหวัด ---------</option>
      <option value="กรุงเทพมหานคร">กรุงเทพมหานคร</option>
      <option value="กระบี่">กระบี่ </option>
      <option value="กาญจนบุรี">กาญจนบุรี </option>
      <option value="กาฬสินธุ์">กาฬสินธุ์ </option>
      <option value="กำแพงเพชร">กำแพงเพชร </option>
      <option value="ขอนแก่น">ขอนแก่น</option>
      <option value="จันทบุรี">จันทบุรี</option>
      <option value="ฉะเชิงเทรา">ฉะเชิงเทรา </option>
      <option value="ชัยนาท">ชัยนาท </option>
      <option value="ชัยภูมิ">ชัยภูมิ </option>
      <option value="ชุมพร">ชุมพร </option>
      <option value="ชลบุรี">ชลบุรี </option>
      <option value="เชียงใหม่">เชียงใหม่ </option>
      <option value="เชียงราย">เชียงราย </option>
      <option value="ตรัง">ตรัง </option>
      <option value="ตราด">ตราด </option>
      <option value="ตาก">ตาก </option>
      <option value="นครนายก">นครนายก </option>
      <option value="นครปฐม">นครปฐม </option>
      <option value="นครพนม">นครพนม </option>
      <option value="นครราชสีมา">นครราชสีมา </option>
      <option value="นครศรีธรรมราช">นครศรีธรรมราช </option>
      <option value="นครสวรรค์">นครสวรรค์ </option>
      <option value="นราธิวาส">นราธิวาส </option>
      <option value="น่าน">น่าน </option>
      <option value="นนทบุรี">นนทบุรี </option>
      <option value="บึงกาฬ">บึงกาฬ</option>
      <option value="บุรีรัมย์">บุรีรัมย์</option>
      <option value="ประจวบคีรีขันธ์">ประจวบคีรีขันธ์ </option>
      <option value="ปทุมธานี">ปทุมธานี </option>
      <option value="ปราจีนบุรี">ปราจีนบุรี </option>
      <option value="ปัตตานี">ปัตตานี </option>
      <option value="พะเยา">พะเยา </option>
      <option value="พระนครศรีอยุธยา">พระนครศรีอยุธยา </option>
      <option value="พังงา">พังงา </option>
      <option value="พิจิตร">พิจิตร </option>
      <option value="พิษณุโลก">พิษณุโลก </option>
      <option value="เพชรบุรี">เพชรบุรี </option>
      <option value="เพชรบูรณ์">เพชรบูรณ์ </option>
      <option value="แพร่">แพร่ </option>
      <option value="พัทลุง">พัทลุง </option>
      <option value="ภูเก็ต">ภูเก็ต </option>
      <option value="มหาสารคาม">มหาสารคาม </option>
      <option value="มุกดาหาร">มุกดาหาร </option>
      <option value="แม่ฮ่องสอน">แม่ฮ่องสอน </option>
      <option value="ยโสธร">ยโสธร </option>
      <option value="ยะลา">ยะลา </option>
      <option value="ร้อยเอ็ด">ร้อยเอ็ด </option>
      <option value="ระนอง">ระนอง </option>
      <option value="ระยอง">ระยอง </option>
      <option value="ราชบุรี">ราชบุรี</option>
      <option value="ลพบุรี">ลพบุรี </option>
      <option value="ลำปาง">ลำปาง </option>
      <option value="ลำพูน">ลำพูน </option>
      <option value="เลย">เลย </option>
      <option value="ศรีสะเกษ">ศรีสะเกษ</option>
      <option value="สกลนคร">สกลนคร</option>
      <option value="สงขลา">สงขลา </option>
      <option value="สมุทรสาคร">สมุทรสาคร </option>
      <option value="สมุทรปราการ">สมุทรปราการ </option>
      <option value="สมุทรสงคราม">สมุทรสงคราม </option>
      <option value="สระแก้ว">สระแก้ว </option>
      <option value="สระบุรี">สระบุรี </option>
      <option value="สิงห์บุรี">สิงห์บุรี </option>
      <option value="สุโขทัย">สุโขทัย </option>
      <option value="สุพรรณบุรี">สุพรรณบุรี </option>
      <option value="สุราษฎร์ธานี">สุราษฎร์ธานี </option>
      <option value="สุรินทร์">สุรินทร์ </option>
      <option value="สตูล">สตูล </option>
      <option value="หนองคาย">หนองคาย </option>
      <option value="หนองบัวลำภู">หนองบัวลำภู </option>
      <option value="อำนาจเจริญ">อำนาจเจริญ </option>
      <option value="อุดรธานี">อุดรธานี </option>
      <option value="อุตรดิตถ์">อุตรดิตถ์ </option>
      <option value="อุทัยธานี">อุทัยธานี </option>
      <option value="อุบลราชธานี">อุบลราชธานี</option>
      <option value="อ่างทอง">อ่างทอง </option>
      <option value="อื่นๆ">อื่นๆ</option>
</select>

	<br>
	<br>
  <input type = button id = "Clear" value = "Clear"></button>     
  <input type = "submit" value = "submit" id = "submit"></button> 

  <br>
</form>
	<br>
	<br>
</div>
</body>
</html>